const gifsPerPage = 6;
let currentPage = 1;

const gifs = [
    "https://media1.tenor.com/m/CiJuhjUFaeIAAAAC/gojo-satoru-jujutsu-kaisen.gif",
    "https://steamuserimages-a.akamaihd.net/ugc/2208514167417886719/9399D877FDD4BDBD6F8E78159932FCBBB5BA869C/?imw=512&&ima=fit&impolicy=Letterbox&imcolor=%23000000&letterbox=false",
    "https://64.media.tumblr.com/35dd1f9c2c2e1478783797a86287bf6d/f432b8ce71e6ac1f-93/s640x960/0e2a6782c5d99ccb4cd702f9c83a16432e1b15c7.gif",
    "https://media.tenor.com/rEg8BNZeuVgAAAAM/jjk-jujutsu-kaisen.gif",
    "https://media1.tenor.com/m/lvF6udHKAIgAAAAC/jujutsu-kaisen0-yuta-okkotsu.gif",
    "https://giffiles.alphacoders.com/219/219539.gif",
    "https://media.tenor.com/PAJdtmYV3g8AAAAM/maki-maki-zenin.gif",
    "https://i.makeagif.com/media/12-11-2023/GqHSN3.gif",
    "https://media.tenor.com/5VlU6tJtQUMAAAAM/mei-mei-mei-mei-jjk.gif",
    "https://media.tenor.com/2tA56I2eTK8AAAAM/jujutsu-kaisen-shinjuku-arc-hajime-kashimo.gif"
];

function showPage(page) {
    const start = (page - 1) * gifsPerPage;
    const end = start + gifsPerPage;
    const gifsToShow = gifs.slice(start, end);

    const gifContainer = document.getElementById('gif-container');
    gifContainer.innerHTML = '';
    gifsToShow.forEach(gif => {
        const img = document.createElement('img');
        img.src = gif;
        gifContainer.appendChild(img);
    });

    document.getElementById('page-info').innerText = `Page ${page}`;
    document.getElementById('prev').disabled = page === 1;
    document.getElementById('next').disabled = end >= gifs.length;
}

document.getElementById('prev').addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        showPage(currentPage);
    }
});

document.getElementById('next').addEventListener('click', () => {
    if (currentPage * gifsPerPage < gifs.length) {
        currentPage++;
        showPage(currentPage);
    }
});

showPage(currentPage);